import formidable from 'formidable';
import fs from 'fs';
import fetch from 'node-fetch';

/**
 * Vercel serverless function for /api/diagnose
 * NOTE: Vercel Edge functions have different APIs. This file targets a Node serverless function.
 * Ensure environment variable OPENAI_API_KEY is set.
 */

export const config = {
  api: {
    bodyParser: false
  }
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).send({ error: 'Method not allowed' });
    return;
  }

  const form = new formidable.IncomingForm();
  const data = await new Promise((resolve, reject) => {
    form.parse(req, (err, fields, files) => {
      if (err) reject(err);
      else resolve({ fields, files });
    });
  });

  const symptom = (data.fields.symptom || '').toString();
  const carinfo = (data.fields.carinfo || '').toString();
  // media handling is left as TODO for production
  const mediaFile = data.files?.media;

  // If media exists: upload to your storage (S3/Supabase) and get a public URL. For now, we'll ignore media.
  const mediaUrl = null;

  const prompt = `
You are a professional automotive mechanic. A user reports: "${symptom}". The car: "${carinfo}".
Return a JSON object ONLY with keys: diagnoses (array), urgency (low|medium|high), followup (string).
Each diagnosis item must have: label, probability (0-1), reason (short), costLow (e.g. "$50"), costHigh (e.g. "$500"), parts (array of {title,link,price}).
Use realistic costs (US dollars). If mediaUrl is present, mention it in reason. Keep answers concise.
`;

  try {
    const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are an expert mechanic that returns structured JSON.' },
          { role: 'user', content: prompt }
        ],
        max_tokens: 700,
        temperature: 0.1
      })
    });

    if (!openaiRes.ok) {
      const txt = await openaiRes.text();
      console.error('OpenAI error', txt);
      res.status(500).send({ error: 'OpenAI error' });
      return;
    }
    const completion = await openaiRes.json();
    const answer = completion.choices?.[0]?.message?.content || '';

    let parsed = null;
    try {
      parsed = JSON.parse(answer);
    } catch (e) {
      parsed = { diagnoses: [{ label: 'Parsing error', probability: 0, reason: answer, costLow: '$0', costHigh: '$0', parts: [] }], urgency: 'medium', followup: 'Manual review recommended.' };
    }

    res.status(200).json(parsed);

  } catch (err) {
    console.error('Server error', err);
    res.status(500).send({ error: 'Server error' });
  }
}
